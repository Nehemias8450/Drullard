/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates*

 * and open the template in the editor.
 */

/**
  * @author nehemias
 */
public class CalMeanST {
    
   

/*
  This method accept an array argument and calculate 
    the mean 
    */
    
    public double getMean(int [] GuiArray) {
    int sum = 0; 
    double mean; 
    for(int i = 0; i < GuiArray.length; i++)
    
       sum+= GuiArray[i];
    
    
    mean = (double)sum / GuiArray.length; 
     return mean;
    }
    
    
    /*
    This method accept an array argument and 
    calculate the standard deviation 
    */
    public double getST(int [] GuiArray)
    
    {
        double mean;
        double sum = 0;
        mean = getMean(GuiArray);
        
        for(int j = 0; j < GuiArray.length; j++)
        {
         sum += Math.pow(GuiArray[j]- mean, 2);
         
        }
        double ST = Math.sqrt(sum/GuiArray.length - 1);
        return ST; 
    }
}
   